#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests
import pandas as pd
import json
import csv
import time
import datetime
import sys
import traceback
from pytz import timezone
import pytz
from html.parser import HTMLParser
from bs4 import BeautifulSoup
from bs4.dammit import EncodingDetector
import re
from pdfminer import high_level
import dateutil.parser as dt_parser
import PyPDF2 
import pdfplumber



eastern = timezone('US/Eastern')
today = eastern.localize(datetime.datetime.now())
today_str_date = today.strftime('%Y-%m-%d 00:00:00')

state_cities = dict()
with open('state_cities.json', 'r') as outfile:
    state_cities = json.load(outfile)
    
empty_states = ['AK', 'HI', 'ME', 'MT', 'NE', 'SD', 'WY']


# In[2]:


def get_arcgis_results(url):
    data = dict()
    req = requests.get(url)
    _json = req.json()

    features = _json.get('features', list())
    if len(features) == 1:
        attrs = features[0].get('attributes')
        return attrs
    elif len(features) > 1:
        return features
    return None


# In[3]:


#  Alabama - arcgis api
#  Alaska - nothing (looked at http://dhss.alaska.gov/dph/Epi/id/Pages/COVID-19/monitoring.aspx)
#  Arizona - has total county - doesn't appear to be an exposed API (https://www.azdhs.gov/preparedness/epidemiology-disease-control/infectious-disease-epidemiology/covid-19/dashboards/index.php)
#  Arkansas - arcgis (% of total cases that are in nursing homes)
#  California - tableau (has older CSVs, but newer stuff is in tableau - no API)
#  Colorado - has CSVs for outbreaks (https://covid19.colorado.gov/data/outbreak-data)
#  Connecticut - available via API (https://data.ct.gov/Health-and-Human-Services/Nursing-Homes-with-Residents-Positive-for-COVID-19/wyn3-qphu)
#  Delaware - nothing from https://myhealthycommunity.dhss.delaware.gov/locations/state
#  DC - nothing from https://coronavirus.dc.gov/page/coronavirus-data
#  Florida - nothing - has arcgis and data dashboard (https://experience.arcgis.com/experience/96dd742462124fa0b38ddedb9b25e429/)
#  Georgia - PDF report by facility - https://dch.georgia.gov/announcement/2020-06-23/long-term-care-facility-covid-19-report
#  Hawaii - nothing from https://health.hawaii.gov/coronavirusdisease2019/
#  Idaho - PDF report https://coronavirus.idaho.gov/ltc/
#  Illinois - Has a site and an API - http://www.dph.illinois.gov/sitefiles/COVIDLTC.json?nocache=1 (http://www.dph.illinois.gov/covid19/long-term-care-facility-outbreaks-covid-19)
#  Indiana - Has a site - potential API - https://www.coronavirus.in.gov/2393.htm
#  Iowa - has a DOMO viz, might be able to pull from API (https://coronavirus.iowa.gov/pages/long-term-care)
#  Kansas - nothing (have tableau but no LTCF data) (looked here https://www.coronavirus.kdheks.gov/160/COVID-19-in-Kansas)
#  Kentucky - PDF (https://chfs.ky.gov/agencies/dph/covid19/LTCupdate.pdf)
#  Louisiana - PDF (http://ldh.la.gov/index.cfm/page/3965)
#  Maine - nothing (looked at https://www.maine.gov/dhhs/mecdc/infectious-disease/epi/airborne/coronavirus/data.shtml)
#  Maryland - arcgis (likely can pull from API) - https://coronavirus.maryland.gov/pages/hcf-resources
#  Massachusetts - PDF (https://www.mass.gov/info-details/eohhs-covid-19-reporting - click link)
#  Michigan - website, but just HTML so easy to scrape (https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173-526911--,00.html)
#  Minnesota - website, but could scrape from html (https://www.health.state.mn.us/diseases/coronavirus/situation.html#res1)
#  Mississippi - PDFs (https://msdh.ms.gov/msdhsite/_static/14,0,420.html#ltcTable)
#  Missouri - has arcgis for congregate living - can likely get from API (http://mophep.maps.arcgis.com/apps/MapSeries/index.html?appid=8e01a5d8d8bd4b4f85add006f9e14a9d)
#  Montana - nothing (has arcgis but didn't see a breakout for ltcf https://montana.maps.arcgis.com/apps/MapSeries/index.html?appid=7c34f3412536439491adcc2103421d4b)
#  Nebraska - has website (HTML scrapable) and PDF (https://covid19.ncdhhs.gov/dashboard/outbreaks-and-clusters)
#  Nevada - PowerBI - not obs. how to get data out (https://app.powerbigov.us/view?r=eyJrIjoiNDMwMDI0YmQtNmUyYS00ZmFjLWI0MGItZDM0OTY1Y2Y0YzNhIiwidCI6ImU0YTM0MGU2LWI4OWUtNGU2OC04ZWFhLTE1NDRkMjcwMzk4MCJ9)
#  New Hampshire - tableau - not obs. how to get data out (https://www.nh.gov/covid19/dashboard/summary.htm)
#  New Jersey - arcgic api - https://covid19.nj.gov/#live-updates - 
#  New Mexico - nothing, has prisons though - https://cvprovider.nmhealth.org/public-dashboard.html
#  New York - PDF https://www.health.ny.gov/statistics/diseases/covid-19/fatalities_nursing_home_acf.pdf
#  North Carolina - https://covid19.ncdhhs.gov/dashboard/outbreaks-and-clusters
#  North Dakota - HTML site (should be able to be scraped) - https://www.health.nd.gov/diseases-conditions/coronavirus/north-dakota-coronavirus-cases
#  Ohio - tableau - not easy to scrape - https://coronavirus.ohio.gov/wps/portal/gov/covid-19/dashboards/long-term-care-facilities/cases
#  Oklahoma - nothing, looked here - https://coronavirus.health.ok.gov/
#  Oregon - nothing (have tableau but don't see LTCF - https://public.tableau.com/profile/oregon.health.authority.covid.19#!/vizhome/OregonCOVID-19PublicHealthIndicators/COVID-19Burden)
#  Pennsylvania - has excel and HTML site (https://www.health.pa.gov/topics/disease/coronavirus/Pages/LTCF-Data.aspx)
#  Rhode Island - has google sheet (easy to scrape) - https://docs.google.com/spreadsheets/d/e/2PACX-1vROn5SxAFt840DsyghnNEXx0G1sAlHPyCCtJMoWSysI4dtU2DpWFsA63BGzOPp3EqeDkUgQzQIhjul6/pubhtml?gid=666863098&single=true
#  South Carolina - PDF (has links here https://scdhec.gov/infectious-diseases/viruses/coronavirus-disease-2019-covid-19/sc-demographic-data-covid-19)
#  South Dakota - nothing (looked here https://doh.sd.gov/news/Coronavirus.aspx#Trend)
#  Tennessee - nothing (looked here https://www.tn.gov/health/cedep/ncov.html)
#  Texas - HTML and Excel (https://dshs.texas.gov/coronavirus/COVID-19OutbreaksinLong-termCareFacilities.aspx)
#  Utah - arcgis and HTML table (should be extractable) (https://coronavirus-dashboard.utah.gov/#outbreaks)
#  Vermont - nothing (have arcgis but don't see LTCF https://www.healthvermont.gov/response/coronavirus-covid-19/current-activity-vermont#dashboard)
#  Virginia - tableau dashboard (might be harder to get out) (https://www.vhha.com/communications/virginia-licensed-nursing-facility-covid-19-dashbaord/)
#  Washington - PDF report (https://www.doh.wa.gov/Portals/1/Documents/1600/coronavirus/data-tables/Weekly-COVID-19-Long-Term-Care-Report.pdf)
#  West Virginia - PowerBI Dashboard (https://dhhr.wv.gov/COVID-19/Pages/default.aspx)
#  Wisconsin - has HTML and Tableau (https://www.dhs.wisconsin.gov/covid-19/investigations.htm)
#  Wyoming - nothing (looked here - https://health.wyo.gov/publichealth/infectious-disease-epidemiology-unit/disease/novel-coronavirus/covid-19-map-and-statistics/)


# In[4]:



def AL():
    data = dict()
    req = requests.get('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/c19v2_hcw_ltcf_PUBLIC/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&resultOffset=0&resultRecordCount=50&resultType=standard&cacheHint=true')
    _json = req.json()

    features = _json.get('features', list())
    if len(features) == 1:
        attrs = features[0].get('attributes')
#         print(attrs)
        data['LTCF_employee_count'] = attrs.get('LTCF_Employee')
        data['LTCF_patient_count'] = attrs.get('LTCF_Resident')
        data['LTCF_total'] = int(attrs.get('LTCF_Employee')) + attrs.get('LTCF_Resident')
        data['date'] = today_str_date
    return data
    
# AL()


# In[5]:


def AZ():
    url = 'https://tableau.azdhs.gov/views/Outbreaks/Outbreaks-New?:embed=y&:host_url=https%3A%2F%2Ftableau.azdhs.gov%2F&:showAppBanner=false&:display_spinner=no&:loadOrderID=1'
    return {}
    
# AZ()


# In[6]:


def AK():
    return {}


# In[7]:


def AR():
    res = requests.get('https://services.arcgis.com/PwY9ZuZRDiI5nXUB/arcgis/rest/services/ADH_COVID19_State_Case_Metrics/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&resultOffset=0&resultRecordCount=50&resultType=standard&cacheHint=true')
    _json = res.json()
    data = {}
    features = _json.get('features', list())
    if len(features) == 1:
        attrs = features[0].get('attributes')
        data['LTCF_employee_count'] = None
        data['LTCF_patient_count'] = None
        data['LTCF_total'] = attrs.get('nursing_home')
        data['date'] = today_str_date
    return data


      
        


# In[8]:


# Go to https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/SNFsCOVID_19.aspx. 
# For Residents and HCP cases and deaths, use the main dashboard information presented on the page1.
# Resident Cases2. HCW Cases3. Resident Deaths4. HCW Deaths
def CA():
    return {}


# In[9]:


def CO():
    res = requests.get('https://covid19.colorado.gov/data/outbreak-data')
    html_doc = res.text
    soup = BeautifulSoup(html_doc, 'html.parser')
    file_span = soup.find("span", {"class": "file-link"})

    file_link = file_span.find('a')['href']
    print(file_link)
    
    res = requests.get(file_link)
    with open('stage/co.xlsx', 'wb') as wb:
        wb.write(res.content)
        
    df = pd.read_excel('stage/co.xlsx', sheet_name=1)
    data = {}
    total_staff = 0
    total_residents = 0
    total_staff_d = 0
    total_residents_d = 0
    facilities = list()
    for i, row in df.iterrows():
        setting = row['Setting type']
        county = row['Colorado county (exposure location)']
        status = row['Investigation status']
        name = row['Setting name']
        setting_type = row['Setting type']
        
        if 'skilled nursing' not in setting_type:
            continue
            
        dt = row['Date illnesses were determined to be an outbreak']
        str_date = dt.strftime('%Y-%m-%d 00:00:00')
            
        residents = row['Number of residents positive for COVID-19 (lab confirmed)']
        staff = row['Number of staff who are positive for COVID-19 (lab confirmed)']
        residents_d = row['Number of COVID-19 deaths (lab confirmed/confirmed)']
        staff_d = row['Number of COVID-19 staff deaths (lab confirmed/confirmed)']
        
        try:
            residents = int(residents)
        except:
            residents = 0
            
        try:
            staff = int(staff)
        except:
            staff = 0
            
        try:
            residents_d = int(residents_d)
        except:
            residents_d = 0
        try:
            staff_d = int(staff_d)
        except:
            staff_d = 0
        fac = {
            'name': name,
            'county': county,
            'city': '',
            'state': 'CO',
            'status': status,
            'date': str_date,
            'employee_count': staff,
            'patient_count': residents,
            'total': staff + residents,
            'employee_deaths': staff_d,
            'patient_deaths': residents_d,
            'total_deaths': staff_d + residents_d
        }
        facilities.append(fac)
            
        total_staff += staff
        total_residents += residents
    data['LTCF_employee_count'] = total_staff
    data['LTCF_patient_count'] = total_residents
    data['LTCF_total'] = total_staff + total_residents
    data['LTCF_employee_deaths'] = total_staff_d
    data['LTCF_patient_deaths'] = total_residents_d
    data['LTCF_total_deaths'] = total_staff_d + total_residents_d
    data['facilities'] = facilities
    data['date'] = today_str_date
        
    return data
    


# In[10]:


def CT():
    res = requests.get('https://data.ct.gov/resource/wyn3-qphu.json')
    data = {}
    _json = res.json()
    total_residents = 0
    total_deaths = 0
    facilities = list()
    cities = state_cities['CT']
    for r in _json:
        residents = int(r.get('residents_with_covid'))
        dt = dt_parser.parse(r.get('date_last_updated'))
        str_date = dt.strftime('%Y-%m-%d 00:00:00')
        city = r.get('town')
        place = cities.get(city, dict())
        probable_deaths = int(r.get('covid_19_associated_deaths_probable'))

        fac = {
            'name': r.get('nursing_home'),
            'county': place.get('county_name', ''),
            'city': city,
            'state': 'CT',
            'status': '',
            'date': str_date,
            'employee_count': None,
            'patient_count': residents,
            'total': None,
            'total_deaths': probable_deaths
        }
        facilities.append(fac)
            
        total_deaths += probable_deaths
        total_residents += residents
    data['LTCF_employee_count'] = None
    data['LTCF_patient_count'] = total_residents
    data['LTCF_total'] = None
    data['facilities'] = facilities
    data['LTCF_employee_deaths'] = None
    data['LTCF_patient_deaths'] = None
    data['LTCF_total_deaths'] = total_deaths
    data['date'] = today_str_date
        
    return data



# In[11]:


#  Delaware - nothing from https://myhealthycommunity.dhss.delaware.gov/locations/state
#  DC - nothing from https://coronavirus.dc.gov/page/coronavirus-data
#  Florida - nothing - has arcgis and data dashboard (https://experience.arcgis.com/experience/96dd742462124fa0b38ddedb9b25e429/)
def DE():
    return {}
def DC():
    return {}
def FL():
    return {}


# In[12]:


def GA():
    res = requests.get('https://dch.georgia.gov/announcement/2020-06-29/long-term-care-facility-covid-19-report')
    html_doc = res.text
    soup = BeautifulSoup(html_doc, 'html.parser')
    file_span = soup.find("span", {"class": "inline-document-link"})

    file_link = file_span.find('a')['href']
    print(file_link)
    
    res = requests.get(file_link)
    with open('stage/ga.pdf', 'wb') as wb:
        wb.write(res.content)
    pdfFileObj = open('stage/ga.pdf', 'rb')
    print(first_page.chars[0])
    pdfReader = PyPDF2.PdfFileReader(pdfFileObj) 
#     print(pdfReader.numPages) 
    pageObj = pdfReader.getPage(0) 
#     print(pageObj.extractText()) 
    pdfFileObj.close()
    return {}


# In[13]:


#  Hawaii - nothing from https://health.hawaii.gov/coronavirusdisease2019/

def HI():
    return {}

def ID():
    #  Idaho - PDF report https://coronavirus.idaho.gov/ltc/
    return {}


# In[14]:


def IL():
    #  Illinois - Has a site and an API - http://www.dph.illinois.gov/sitefiles/COVIDLTC.json?nocache=1 (http://www.dph.illinois.gov/covid19/long-term-care-facility-outbreaks-covid-19)
    res = requests.get('http://www.dph.illinois.gov/sitefiles/COVIDLTC.json?nocache=1')
    _json = res.json()
    data = {}
    LTC_Reported_Cases = _json.get('LTC_Reported_Cases')
    FacilityValues = _json.get('FacilityValues')
    facilities = list()
    total_deaths = 0
    for r in FacilityValues:
        fac = {
            'name': r.get('FacilityName'),
            'county': r.get('County'),
            'city': '',
            'state': 'IL',
            'status': r.get('status'),
            'date': None,
            'employee_count': None,
            'patient_count': None,
            'total': r.get('confirmed_cases'),
            'employee_deaths': None,
            'patient_deaths': None,
            'total_deaths': r.get('deaths')
        }
        facilities.append(fac)
    data['LTCF_employee_count'] = None
    data['LTCF_patient_count'] = None
    data['LTCF_total'] = int(LTC_Reported_Cases.get('confirmed_cases'))
    data['facilities'] = facilities
    data['LTCF_employee_deaths'] = None
    data['LTCF_patient_deaths'] = None
    data['LTCF_total_deaths'] = int(LTC_Reported_Cases.get('deaths'))
    data['date'] = today_str_date
    return data
  


# In[15]:


#  Indiana - Has a site - potential API - https://www.coronavirus.in.gov/2393.htm
def IN():
    res = requests.get('https://www.coronavirus.in.gov/map/covid-19-indiana-daily-report-current.topojson')
    _json = res.json()
    objects = _json.get('objects')
    weekly_ltc = objects.get('weekly_ltc')
    this_week = weekly_ltc[-1]
    data = dict()
    data['LTCF_employee_count'] = None
    data['LTCF_patient_count'] = None
    data['LTCF_total'] = this_week.get('TOTAL_COVID_POSITIVE_CASES_LTC')
    data['LTCF_employee_deaths'] = None
    data['LTCF_patient_deaths'] = None
    data['LTCF_total_deaths'] = this_week.get('TOTAL_COVID_DEATH_CASES_LTC')
    data['date'] = dt_parser.parse(this_week.get('DATE')).strftime('%Y-%m-%d 00:00:00')
    return data


# In[16]:


def IA():
    res = requests.get('https://public.domo.com/embed/pages/dRWq0')
    html_doc = res.text
    c = re.compile(r'x-domo-embed-token.+')
    m = c.search(html_doc)
    token = ''
    if m:
        token_str = m.group()
        spl = token_str.split("'")
        token = spl[2]
    if token == '':
        return {}
    data = {}
    res = requests.put('https://public.domo.com/embed/pages/dRWq0/cards/850461773/render?parts=dynamic,summary,annotations',
                      headers={
                          'accept': 'application/json',
                          'x-domo-embed-token': token
                      }, 
                      json={"queryOverrides":{"filters":[]},"transparent":True,"textColor":"#54585A","scaleLineColor":"#D3D3D2","imageMap":True,"pageLayout":True,"width":1824,"height":1510,"scale":2,"cardLinking":True,"cardLoadContext":{"context":"page","sessionId":"1234","visibilityState":"visible","contextId":"dRWq0","trigger":"initial_load"}}
                      )
    _json = res.json()
    chart = _json.get('chart', dict())
    datasources = chart.get('datasources', dict())
    keys = list(datasources.keys())
    facilities = list()
    if len(keys) > 0:
        key = keys[0]
        key_data = datasources.get(key)
        res_data = key_data.get('data')
        rows = res_data.get('rows')
        total = 0
        for r in rows:


            fac = {
                'name': r[1],
                'county': r[0],
                'city': '',
                'state': 'IA',
                'status': '',
                'date': None,
                'employee_count': None,
                'patient_count': None,
                'total': r[2]
            }
            total += r[2]
            facilities.append(fac)
        data['LTCF_employee_count'] = None
        data['LTCF_patient_count'] = None
        data['LTCF_total'] = total
        
    res = requests.put('https://public.domo.com/embed/pages/dRWq0/cards/717104727/render?parts=dynamic,summary',
                  headers={
                      'accept': 'application/json',
                      'x-domo-embed-token': token
                  }, 
                  json={"queryOverrides":{"filters":[]},"transparent":True,"textColor":"#54585A","scaleLineColor":"#D3D3D2","imageMap":True,"pageLayout":True,"width":522,"height":190,"scale":2,"cardLinking":True,"cardLoadContext":{"context":"page","sessionId":"6b59ded6-ea0a-4c0e-9ea2-3cdd5c4d13a5","visibilityState":"visible","contextId":"dRWq0","trigger":"initial_load"}}
                      )
    _json = res.json()
    chart = _json.get('chart', dict())
    datasources = chart.get('datasources', dict())
    keys = list(datasources.keys())
    total_deaths = None
    if len(keys) > 0:
        key = keys[0]
        key_data = datasources.get(key)
        res_data = key_data.get('data')
        rows = res_data.get('rows')
        total = 0
        for r in rows:
            total_deaths = r[0]

    data['LTCF_employee_deaths'] = None
    data['LTCF_patient_deaths'] = None
    data['LTCF_total_deaths'] = total_deaths
    data['facilities'] = facilities
    data['date'] = today_str_date
        
    return data


    


# In[17]:



def KS():
    # Go to: https://www.coronavirus.kdheks.gov/DocumentCenter/View/1125/Historical---June-22?bidId= 
    # Cases are listed by clusters and county.  
    # Cases and deaths may include resident and staff data combined. 
    return {}

def KY():
    #  Kentucky - PDF (https://chfs.ky.gov/agencies/dph/covid19/LTCupdate.pdf)
    return {}

def LA():
    #  Louisiana - PDF (http://ldh.la.gov/index.cfm/page/3965)
    return {}
def ME():
    return {}


# In[18]:


def MD():
    res = requests.get('https://services.arcgis.com/njFNhDsUCentVYJW/arcgis/rest/services/Maryland_Congregate_Living_COVID19_Cases_Assisted/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Facility_Name%20asc&resultOffset=0&resultRecordCount=230&resultType=standard&cacheHint=true')
    _json = res.json()
    data = {}
    facilities = list()
    features = _json.get('features', list())
    total_residents = 0
    total_staff = 0
    total = 0    
    total_residents_d = 0
    total_staff_d = 0
    if len(features) > 0:
        for f in features:
            attrs = f.get('attributes')
            staff_deaths = attrs.get('Number_of_Staff_Deaths')
            res_deaths = attrs.get('Number_of_Resident_Deaths')
            fac = {
                'name': attrs.get('Facility_Name'),
                'county': attrs.get('County'),
                'city': '',
                'state': 'MD',
                'status': '',
                'date': None,
                'employee_count': attrs.get('Number_of_Staff_Cases'),
                'patient_count': attrs.get('Number_of_Resident_Cases'),
                'total': attrs.get('Total_Cases'),
                'employee_deaths': staff_deaths,
                'patient_deaths': res_deaths,
                'total_deaths': res_deaths + staff_deaths
            }
            total += attrs.get('Total_Cases')
            total_residents += attrs.get('Number_of_Resident_Cases')
            total_staff += attrs.get('Number_of_Staff_Cases')
            total_staff_d += staff_deaths
            total_residents_d += res_deaths
            facilities.append(fac)

    data['LTCF_employee_count'] = total_staff
    data['LTCF_patient_count'] = total_residents
    data['LTCF_total'] = total
    data['LTCF_employee_deaths'] = total_staff_d
    data['LTCF_patient_deaths'] = total_residents_d
    data['LTCF_total_deaths'] = total_residents_d + total_staff_d
    data['facilities'] = facilities
    data['date'] = today_str_date
    return data
    


# In[19]:


def MA():
    # Go to:  https://www.mass.gov/info-details/covid-19-response-reporting 
    # Scroll to “Table of Contents” and click on COVID-19 Daily Dashboard 
    # Scroll to link for latest Dashboard report and click on link 
    # Scroll throughx slides to “COVID-19 Cases in Long-Term Care (LTC) Facilities” 
    return {}


# In[20]:


def MI():
    data = {}
    url = 'https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173-526911--,00.html'
    res = requests.get(url)
    html_doc = res.text
    soup = BeautifulSoup(html_doc, 'html.parser')
    tables = soup.find_all('table')
    total_table = tables[0]

    total_residents = 0
    total_staff = 0
    total_staff_d = 0
    total_residents_d = 0
    total = 0
    facilities = list()
    for tr in total_table.find_all('tr'):
        try:
            tds = tr.find_all('td')
            td0 = tds[0].get_text().strip()
            td1 = int(tds[1].get_text())


            if 'Resident Confirmed Cases' in td0:
                total_residents = td1
            if 'Staff Confirmed Cases' in td0:
                total_staff = td1
            if 'Resident COVID-19 Deaths' in td0:
                total_residents_d = td1
            if 'Staff COVID-19 Deaths' in td0:
                total_staff_d = td1
                
        except Exception as ex:
            continue
    facilities_table = tables[2]
    county = None
    for tr in facilities_table.find_all('tr'):
        try:
            tds = tr.find_all('td')
            td0 = tds[0].get_text().strip()
            if td0 == '':
                continue
            if len(tds) == 3:
                county = td0.title()

                continue
            if 'Facility Name' in td0:
                continue

            try:
                staff_cases = int(tds[3].get_text().strip())
            except:
                staff_cases = 0
            try:
                pat_cases = int(tds[1].get_text().strip())
            except:
                pat_cases = 0
            try:
                staff_deaths = int(tds[4].get_text().strip())
            except:
                staff_deaths = 0
            try:
                pat_deaths = int(tds[2].get_text().strip())
            except:
                pat_deaths = 0
            fac = {
                'name': td0.replace('~', ''),
                'county': county,
                'city': '',
                'state': 'MI',
                'status': '',
                'date': None,
                'employee_count': staff_cases,
                'patient_count': pat_cases,
                'total': staff_cases + pat_cases,
                'employee_deaths': staff_deaths,
                'patient_deaths': pat_deaths,
                'total_deaths': pat_deaths + staff_deaths
            }
            facilities.append(fac)
        except:
            continue
            
    data['LTCF_employee_count'] = total_staff
    data['LTCF_patient_count'] = total_residents
    data['LTCF_total'] = total_staff + total_residents
    data['LTCF_employee_deaths'] = total_staff_d
    data['LTCF_patient_deaths'] = total_residents_d
    data['LTCF_total_deaths'] = total_residents_d + total_staff_d
    data['facilities'] = facilities
    data['date'] = today_str_date
    
    

    return data
    


# In[21]:


def MN():
    data = {}
    #  Minnesota - website, but could scrape from html (https://www.health.state.mn.us/diseases/coronavirus/situation.html#res1)
    
    res = requests.get('https://www.health.state.mn.us/diseases/coronavirus/situation.html#res1')
    html_doc = res.text
    soup = BeautifulSoup(html_doc, 'html.parser')
    table = soup.find("table", {"id": "restable"})
  
    facilities = list()
    for tr in table.find_all('tr'):
        th = tr.find_all('th')
        td = tr.find_all('td')
        if len(th) == 1 and len(td) >= 1:
            label = th[0].get_text().strip()
            value = int(td[0].get_text().strip().replace(',', ''))
            if 'Long-term care facility' in label:
                data['LTCF_total'] = value
    ccftable =  soup.find("table", {"id": "ccftable"})    
    for tr in ccftable.find_all('tr'):
        th = tr.find_all('th')
        td = tr.find_all('td')
        if len(th) == 1 and len(td) >= 1:
            county = th[0].get_text().strip()
            name = td[0].get_text().strip().replace(',', '')
            fac = {
                'name': name,
                'county': county,
                'city': '',
                'state': 'MI',
                'status': '',
                'date': None,
                        }
            facilities.append(fac)
    data['LTCF_employee_count'] = None
    data['LTCF_patient_count'] = None
    data['facilities'] = facilities
    data['date'] = today_str_date
    return data


# In[22]:


def MS():
#     Go to https://www.msdh.ms.gov/msdhsite/_static/14,0,420.html 
# Scroll to COVID-19 in Mississippi 
# Take LTC Outbreaks number 
# Scroll to Cases and Outbreaks by County and take totals of Total LTC Facility Cases and Total LTC Facility Deaths  
# Facility level report may have more cases and the HCP information. 
# https://www.msdh.ms.gov/msdhsite/_static/resources/8659.pdf 
    return {}


# In[23]:


def MO():
# Go to https://health.mo.gov/living/healthcondiseases/communicable/novel-coronavirus/results.php
# Click on Demographics tab
# Hover over all counties and count up number of facilities

    data = dict()
        
    return data



# In[24]:


# Montana - nothing (has arcgis but didn't see a breakout for ltcf https://montana.maps.arcgis.com/apps/MapSeries/index.html?appid=7c34f3412536439491adcc2103421d4b)
def MT():
    data = {}
    return data


# In[25]:


def NE():
    data = {}

#  Nebraska - don't see anything


# In[26]:


def NV():
    data = {}
    return data
#  Nevada - PowerBI - not obs. how to get data out (https://app.powerbigov.us/view?r=eyJrIjoiNDMwMDI0YmQtNmUyYS00ZmFjLWI0MGItZDM0OTY1Y2Y0YzNhIiwidCI6ImU0YTM0MGU2LWI4OWUtNGU2OC04ZWFhLTE1NDRkMjcwMzk4MCJ9)
# Go to: https://app.powerbigov.us/view?r=eyJrIjoiNDMwMDI0YmQtNmUyYS00ZmFjLWI0MGItZDM0OTY1Y2Y0YzNhIiwidCI6ImU0YTM0MGU2LWI4OWUtNGU2OC04ZWFhLTE1NDRkMjcwMzk4MCJ9 
# Select Assisted Living and Skilled Nursing, interface glitches if multiple are selected.  
# Take number of resident cases, staff cases, facilities, resident deaths, staff deaths. 
# Sum together respective values between assisted living and skilled nursing.




# In[27]:


def NH():
    data = {}
    return data

#  New Hampshire - tableau - not obs. how to get data out (https://www.nh.gov/covid19/dashboard/summary.htm)
# Go to: https://www.nh.gov/covid19/dashboard/summary.htm 
# Grab the Infections and Deaths values for Long-Term Care Settings**. 
# Go to: https://www.nh.gov/covid19/news/updates.htm 
# To obtain facility list and thus number of facilities with cases: 
# Cycle through several starting with most recent, some may contain the facilities: 
#     for example: https://www.nh.gov/covid19/news/documents/covid-19-update-06052020.pdf 


# In[28]:





def NJ():
    data = {}
    data = dict()
    res_deaths = get_arcgis_results('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cumulative_COVID_deaths_Reporte%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')
    staff_deaths = get_arcgis_results('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cumulative_COVID_deaths_Repor_1%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')
    res_cases = get_arcgis_results('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cumulative_COVID_Cases_Reported%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')
    staff_cases = get_arcgis_results('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cumulative_COVID_Cases_Report_1%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')
    total_facilities = get_arcgis_results('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Number_of_Facilities___Cumulati%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')
    
    data['LTCF_employee_count'] = staff_cases.get('value')
    data['LTCF_patient_count'] = res_cases.get('value')
    data['LTCF_total'] = staff_cases.get('value') + res_cases.get('value')
    data['LTCF_employee_deaths'] = staff_deaths.get('value')
    data['LTCF_patient_deaths'] = res_deaths.get('value')
    data['LTCF_total_deaths'] = staff_deaths.get('value') + res_deaths.get('value')
    data['LTCF_total_facilities'] = total_facilities.get('value')
    data['facilities'] = list()
    data['date'] = today_str_date
    return data
#  New Jersey - arcgis api - https://maps.arcgis.com/apps/MapSeries/index.html?appid=c2efd1898e48452e83d7218329e953d7


# In[29]:


def NM():
    data = {}
    return data
#  New Mexico - nothing, has prisons though - https://cvprovider.nmhealth.org/public-dashboard.html
# Go to: https://cv.nmhealth.org/newsroom/
# Select latest “Updated New Mexico COVID-19 cases: Now at XXXX”
# Scroll down and count up facilities after: 
#     “The Department of Health has identified at least one positive COVID-19 case in residents and/or staff in the past 28 days at the following long-term care and acute care facilities”
#     Compare facilities to previous facilities



# In[30]:


#  New York - PDF https://www.health.ny.gov/statistics/diseases/covid-19/fatalities_nursing_home_acf.pdf
def NY():
    data = {}
    return data


# In[31]:


def NC():
    data = {}
    res = requests.get('https://files.nc.gov/ncdhhs/documents/files/covid-19/Weekly-COVID19-Ongoing-Outbreaks.pdf')
    fn = 'stage/nc.pdf'
    with open(fn, 'wb') as wb:
        wb.write(res.content)
        
    total_staff = 0
    total_residents = 0
    total_staff_d = 0
    total_residents_d = 0
    facilities = list()
    with pdfplumber.open(fn) as pdf:
        pgs = pdf.pages
        total = (len(pgs))
        for p in pgs:
            tbl = p.extract_table()
            if tbl:
                cols0 = tbl[0]
                cols1 = tbl[1]
                
                cols = list()
                n = 0 
                for c in cols0:
                    if not c or len(c) == 0:
                        cols.append(cols1[n])
                    else:
                        cols.append(cols0[n])
                    n += 1
                
                rows = tbl[2:]
                for r in rows:


                    typ = r[0]
                    if 'Care Facility' in typ or 'Nursing Home' in typ:
                        staff_cases = int(r[3])
                        pat_cases = int(r[9])
                        staff_deaths = int(r[6])
                        pat_deaths = int(r[12])
                        fac = {
                            'name': r[0],
                            'county': r[1],
                            'city': '',
                            'state': 'NC',
                            'status': '',
                            'date': None,
                            'employee_count': staff_cases,
                            'patient_count': pat_cases,
                            'total': staff_cases + pat_cases,
                            'employee_deaths': staff_deaths,
                            'patient_deaths': pat_deaths,
                            'total_deaths': pat_deaths + staff_deaths
                        }
                        facilities.append(fac)
                        total_staff_d += staff_deaths
                        total_residents_d += pat_deaths
                        total_staff += staff_cases
                        total_residents += pat_cases
    
    data['LTCF_employee_count'] = total_staff
    data['LTCF_patient_count'] = total_residents
    data['LTCF_total'] = total_staff + total_residents
    data['LTCF_employee_deaths'] = total_staff_d
    data['LTCF_patient_deaths'] = total_residents_d
    data['LTCF_total_deaths'] = total_residents_d + total_staff_d
    data['LTCF_total_facilities'] = len(facilities)
    data['facilities'] = facilities
    data['date'] = today_str_date
                
    return data

#  North Carolina - https://covid19.ncdhhs.gov/dashboard/outbreaks-and-clusters


# In[32]:


def ND():
    data = {}
    millis = int(round(time.time() * 1000))
    facilities = list()
    with requests.Session() as s:
        download = s.get('https://static.dwcdn.net/data/DlMVc.csv?v={}'.format(millis))
        decoded_content = download.content.decode('utf-8')

        reader = csv.DictReader(decoded_content.splitlines(), delimiter=',')
        total_staff = 0
        total_residents = 0
        for r in reader:

            staff_cases = int(r.get('Current Active Positive Staff'))
            pat_cases = int(r.get(' Current Active Positive Residents'))
            fac = {
                'name': r.get('\ufeffFacility Name'),
                'county': r.get('County'),
                'city': r.get('City'),
                'state': 'ND',
                'status': '',
                'date': None,
                'employee_count': staff_cases,
                'patient_count': pat_cases,
                'total': staff_cases + pat_cases,
                'employee_deaths': None,
                'patient_deaths': None,
                'total_deaths': None
            }

            facilities.append(fac)
            total_staff += staff_cases
            total_residents += pat_cases
        
        data['LTCF_employee_count'] = total_staff
        data['LTCF_patient_count'] = total_residents
        data['LTCF_total'] = total_staff + total_residents
        data['LTCF_employee_deaths'] = None
        data['LTCF_patient_deaths'] = None
        data['LTCF_total_deaths'] = None
        data['LTCF_total_facilities'] = len(facilities)
        data['facilities'] = facilities
        data['date'] = today_str_date
        return data


#  North Dakota - HTML site (should be able to be scraped) - https://www.health.nd.gov/diseases-conditions/coronavirus/north-dakota-coronavirus-cases


# In[33]:


def OH():
    data = {}
    return data
#  Ohio - tableau - not easy to scrape - https://coronavirus.ohio.gov/wps/portal/gov/covid-19/dashboards/long-term-care-facilities/cases


# In[34]:


def OK():
    data = {}
    return data

# Go to: https://coronavirus.health.ok.gov/weekly-epidemiology-and-surveillance-report and find the most recent report.  
# For example https://coronavirus.health.ok.gov/sites/g/files/gmc786/f/2020.06.05_weekly_epi_report.pdf
# Find the LTCF Resident/Staff Cases and Deaths and record numbers. 
# Go to: https://coronavirus.health.ok.gov/executive-order-reports and find the latest report:  
# For example: https://coronavirus.health.ok.gov/sites/g/files/gmc786/f/eo_-_covid-19_report_-_6-11-20.pdf 
# Take the higher of the two data set in terms of totals. 


# In[35]:


def OR():
    data = {}
    return data

# Go to: https://www.oregon.gov/oha/PH/DISEASESCONDITIONS/DISEASESAZ/Emerging%20Respitory%20Infections/COVID-19-Weekly-Report-2020-06-17-FINAL.pdf
# Use the latest wednesdays date 
# Scroll to the section named "Weekly Care Facility, Senior Living Communities and Congregate Living Settings Report"
# Table 5 is active outbreaks while table 6 is resolved outbreak
# Total facilities would be sum of facility names on both list
# total cases would be sum of total cases from both tables
# Total deaths would be sum of toal deaths from both lists


# In[36]:


def PA():
    
    data = {}
    url = 'https://www.health.pa.gov/topics/disease/coronavirus/Pages/LTCF-Data.aspx'
    res = requests.get(url)
    html_doc = res.text
    soup = BeautifulSoup(html_doc, 'html.parser')
    links = soup.find_all('a', href=True)
    covid_ltc = None
    covid_asstd = None
    facilities = list()
    total_staff = 0
    total_residents = 0
    total_residents_d = 0
    for a in links:
        txt = a.get_text().strip()
        if not covid_ltc and txt == 'COVID-19 Long-Term Care Facilities Data':
            covid_ltc = 'https://www.health.pa.gov' + a['href']
        if not covid_asstd and txt == 'COVID-19 Personal Care and Assisted Living Data':
            covid_asstd ='https://www.health.pa.gov' + a['href']
    if covid_ltc:
        res = requests.get(covid_ltc)
        with open('stage/pa_ltc.xlsx', 'wb') as wb:
            wb.write(res.content)
            df = pd.read_excel('stage/pa_ltc.xlsx')
            for i, row in df.iterrows():
                name = row['NAME']
                city = row['CITY']
                county = row['COUNTY']
                staff_cases = 0
                pat_cases = 0
                patient_deaths = 0
                try:
                    pat_cases = int(row['Resident Cases to Display'])
                except:
                    pass
                try:
                    patient_deaths = int(row['Resident Deaths to Display'])
#                     print(patient_deaths)
                    if patient_deaths > pat_cases:
                        patient_deaths = 0
                except:
                    pass
                try:
                    staff_cases = int(row['Staff Cases to Display'])
                except:
                    pass
                total_residents_d += patient_deaths
                total_staff += staff_cases
                total_residents += pat_cases
                fac = {
                    'name': name,
                    'county': county,
                    'city': city,
                    'state': 'PA',
                    'status': '',
                    'date': None,
                    'employee_count': staff_cases,
                    'patient_count': pat_cases,
                    'total': staff_cases + pat_cases,
                    'employee_deaths': None,
                    'patient_deaths': patient_deaths,
                    'total_deaths': None
                }
                facilities.append(fac)
    if covid_asstd:
        res = requests.get(covid_asstd)
        with open('stage/pa_asstd.xlsx', 'wb') as wb:
            wb.write(res.content)
            # TODO
    data['LTCF_employee_count'] = total_staff
    data['LTCF_patient_count'] = total_residents
    data['LTCF_total'] = total_staff + total_residents
    data['LTCF_employee_deaths'] = None
    data['LTCF_patient_deaths'] = total_residents_d
    data['LTCF_total_deaths'] = None
    data['LTCF_total_facilities'] = len(facilities)
    data['facilities'] = facilities
    data['date'] = today_str_date    
    return data

#  Pennsylvania - has excel and HTML site (https://www.health.pa.gov/topics/disease/coronavirus/Pages/LTCF-Data.aspx)


# In[37]:


def RI():
    data = {}
    url = 'https://docs.google.com/spreadsheets/d/1c2QrNMz8pIbYEKzMJL7Uh2dtThOJa2j1sSMwiDo5Gz4/export?format=xlsx'
    
    res = requests.get(url)
    fn = 'stage/ri_ltc.xlsx'
    with open(fn, 'wb') as wb:
        wb.write(res.content)
        
    df = pd.read_excel(fn, sheet_name='Sheet3') 
    return data

# Go to: https://ri-department-of-health-covid-19-data-rihealth.hub.arcgis.com/
# Scroll to 'Long Term Care and Assistde Living Data
# Manually count rows for facility count
# Sum Cumulative resident cases for LTCF and Assisted Living Facilites sections
# Sum Cumulative Resident Fatalities for LTCF and Assisted Living Facility sections

#  Rhode Island - has google sheet (easy to scrape) - https://docs.google.com/spreadsheets/d/e/2PACX-1vROn5SxAFt840DsyghnNEXx0G1sAlHPyCCtJMoWSysI4dtU2DpWFsA63BGzOPp3EqeDkUgQzQIhjul6/pubhtml?gid=666863098&single=true


# In[38]:


def SC():
    data = {}
    return data
#  South Carolina - PDF (has links here https://scdhec.gov/infectious-diseases/viruses/coronavirus-disease-2019-covid-19/sc-demographic-data-covid-19)


# In[39]:


def SD():
    data = {}
    return data

#  South Dakota - nothing (looked here https://doh.sd.gov/news/Coronavirus.aspx#Trend)


# In[40]:


def TN():
    data = {}
    return data

# Go to: https://www.tn.gov/health/cedep/ncov/data/clusters-in-long-term-care-facilities.html
# Page is on an unknown update schedule and does not state when the latest data was updated
# Facilty count is reported as records at top of table 
# Resident case totals are summed at the bottom of column 7 ('COVD POSTIVE RESIDENTS')
# Resident case totals are summed at the bottom of column 8 ('RESIDENT DEATHS')
# HCP case totals are summed at the bottom of column 10 ('COVID POSTIVE STAFF')


# In[41]:


def TX():
    data = {}
    return data

#  Texas - HTML and Excel (https://dshs.texas.gov/coronavirus/COVID-19OutbreaksinLong-termCareFacilities.aspx)


# In[42]:


def UT():
    data = {}
    return data

#  Utah - arcgis and HTML table (should be extractable) (https://coronavirus-dashboard.utah.gov/#outbreaks)


# In[43]:


def VT():
    data = {}
    return data

# Go to: https://www.healthvermont.gov/sites/default/files/documents/pdf/Weekly-Summary-of-Data.pdf
# Files are updated on fridays
# Scroll to outbreaks section and Facility count isreported  as x of Y outbreaks have occurred in facilities
# Resident cases are reported on the main outbreak summary page
# HCP cases are reported on the main outbreak summary page
# Resident deaths are calculated using graph showing death locations (% LTCF) and applying that % to total deaths found on state dashboard
# dashboard - https://www.healthvermont.gov/response/coronavirus-covid-19/current-activity-vermont#dashboard



# In[44]:


def VA():
    data = {}
    return data

#  Virginia - tableau dashboard (might be harder to get out) (https://www.vhha.com/communications/virginia-licensed-nursing-facility-covid-19-dashbaord/)


# In[45]:


def WA():
    data = {}
    return data

#  Washington - PDF report (https://www.doh.wa.gov/Portals/1/Documents/1600/coronavirus/data-tables/Weekly-COVID-19-Long-Term-Care-Report.pdf)


# In[46]:


def WV():
    data = {}
    return data

#  West Virginia - PowerBI Dashboard (https://dhhr.wv.gov/COVID-19/Pages/default.aspx)


# In[47]:


def WI():
    data = {}
    return data

#  Wisconsin - has HTML and Tableau (https://www.dhs.wisconsin.gov/covid-19/investigations.htm)


# In[48]:


def WY():
    data = {}
    return data

#  Wyoming - nothing (looked here - https://health.wyo.gov/publichealth/infectious-disease-epidemiology-unit/disease/novel-coronavirus/covid-19-map-and-statistics/)


# In[49]:


today_file_date = today.strftime('%Y-%m-%d')
with open('stage/ltcf/ltcf_counts_{}.csv'.format(today_file_date), 'w') as csv_file:
    writer1 = csv.writer(csv_file)
    writer1.writerow(['state', 'date_pulled', 'LTCF_total_facilities', 'LTCF_resident_cases_count', 'LTCF_employee_cases_count', 'LTCF_cases_total', 'LTCF_resident_deaths_count', 'LTCF_employee_deaths_count', 'LTCF_deaths_total'])
    with open('stage/ltcf/ltcf_facilities_{}.csv'.format(today_file_date), 'w') as csv_file2:
        writer2 = csv.writer(csv_file2)
        writer2.writerow(['facility_name', 'city', 'county', 'state', 'date_pulled', 'status', 'resident_cases_count', 'employee_cases_count', 'cases_total', 'resident_deaths_count', 'employee_deaths_count', 'deaths_total'])
        
#                         'name': r[1],
#                 'county': r[0lo
#                 'city': '',
#                 'state': 'IA',
#                 'status': '',
#                 'date': None,
#                 'employee_count': None,
#                 'patient_count': None,
#                 'total': r[2]
        sts = ['AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'DC', 'FL', 'GA', 'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'MP', 'OH', 'OK', 'OR', 'PW', 'PA', 'PR', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VI', 'VA', 'WA', 'WV', 'WI', 'WY']
        for s in sts:
            if s in empty_states:
                continue
            try:
                data = eval('{}()'.format(s))
                if not data or data == {}:
                    print('expected data, but empty with {}'.format(s))
                    continue
                LTCF_total_facilities = data.get('LTCF_total_facilities')
                LTCF_employee_count = data.get('LTCF_employee_count')
                LTCF_patient_count = data.get('LTCF_patient_count')
                LTCF_total = data.get('LTCF_total')
                LTCF_employee_deaths = data.get('LTCF_employee_deaths')
                LTCF_patient_deaths = data.get('LTCF_patient_deaths')
                LTCF_total_deaths = data.get('LTCF_total_deaths')
                dt = data.get('date', today_str_date)

                facilities = data.get('facilities', list())
                if not LTCF_total_facilities:
                    LTCF_total_facilities = len(facilities)
                writer1.writerow([s, dt, LTCF_total_facilities, LTCF_patient_count, LTCF_employee_count, LTCF_total, LTCF_patient_deaths, LTCF_employee_deaths, LTCF_total_deaths])

                for f in facilities:
                    writer2.writerow([f.get('name'),
                                      f.get('city'),
                                      f.get('county'),
                                      s,
                                      f.get('date', today_str_date),
                                      f.get('status'),
                                      f.get('patient_count'),
                                      f.get('employee_count'),
                                      f.get('total'),
                                      f.get('patient_deaths'),
                                      f.get('employee_deaths'),
                                      f.get('total_deaths')
                                     ])
                
            except:
                print('error with {}'.format(s))


# In[ ]:




